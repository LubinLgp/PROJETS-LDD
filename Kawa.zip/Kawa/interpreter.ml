  open Kawa

  type value =
    | VInt  of int
    | VBool of bool
    | VObj  of obj
    | VArray of expr list ref
    | Null
  and obj = {
    cls:    string;
    fields: (string, value) Hashtbl.t;
  }

  exception Error of string
  exception Return of value


  let exec_prog (p: program): unit =

    
    
    let find_method (cname:string) (mname:string) =
      match List.find_opt (fun c -> c.class_name = cname) p.classes with
      | Some class_ ->
          ( try
            let m = List.find (fun m -> m.method_name = mname) class_.methods  in
            m
          with
            | Not_found -> failwith (Printf.sprintf "La methode %s est inexistante pour la classe %s" mname cname )
        )
      | None -> let error_msg = Printf.sprintf "La classe %s est inexistante" cname in
                failwith error_msg
    in

    let find_class (p : program) (cname : string) =
      match List.find_opt (fun c -> c.class_name = cname) p.classes with
      | Some c -> c
      | None ->
          failwith (Printf.sprintf "La classe %s est inexistante." cname)
    in

    let env = Hashtbl.create 16 in
    List.iter (fun (x, _) -> Hashtbl.add env x Null) p.globals;
    
    let static_env = Hashtbl.create 16 in
    List.iter (fun c -> 
        List.iter (fun (attr_name, _, _, is_static, _, _, valeur_option) -> 
            if is_static then 
                Hashtbl.add static_env (Printf.sprintf "%s.%s" c.class_name attr_name) valeur_option
        ) c.attributes
    ) p.classes;

    
    let rec eval_call f this args =
      let lenv = Hashtbl.create 16 in
      Hashtbl.add lenv "this" this;
      List.iter (fun (x,_) -> Hashtbl.add lenv x Null) f.locals;
      List.iter (fun (x, t) -> exec_seq ([Set(Var(x),t)]) lenv) f.locals_init;
      List.iter (fun ((x,_),v) -> Hashtbl.add lenv x v) (List.combine (f.params) args);
      exec_seq (f.code) lenv;
      match Hashtbl.find_opt lenv "return" with
      | Some v -> v
      | None -> match f.method_name with
        | "constructor" -> this
        | _ -> Null

    and exec_seq s lenv =
      let rec evali e = match eval e with
        | VInt n -> n
        | _ -> assert false
      and evalb e = match eval e with
        | VBool b -> b
        | _ -> assert false
      and evalo e = match eval e with
        | VObj o -> o
        | _ -> assert false
      and evalt e = match eval e with
        | VArray l -> l
        | _ -> assert false
      and eval (e: expr): value = match e with
        | Int n  -> VInt n
        | Bool b -> VBool b
        | Array t -> VArray (ref t)
        | Binop(Add, e1, e2) -> VInt(evali e1 + evali e2)
        | Binop(Sub, e1, e2) -> VInt(evali e1 - evali e2)
        | Binop(Mul, e1, e2) -> VInt(evali e1 * evali e2)
        | Binop(Div, e1, e2) -> ( match evali e2 with
                                                      | 0 -> failwith("Division par zero impossible")
                                                      | q -> let n = evali e1 / q in VInt n
                                )
        | Binop (Rem,e1,e2) -> ( match evali e2 with
                                                      | 0 -> failwith("Modulo zero impossible")
                                                      | q -> let n = evali e1 mod q in VInt n
                              )
        | Binop(Lt, e1, e2) -> VBool(evali e1 < evali e2)
        | Binop(Le, e1, e2) -> VBool(evali e1 <= evali e2)
        | Binop(Gt, e1, e2) -> VBool(evali e1 > evali e2)
        | Binop(Ge, e1, e2) -> VBool(evali e1 >= evali e2)

        | Binop(Eq, e1, e2) -> ( match (eval e1,eval e2) with
                                                              | (VInt n, VInt m) -> VBool (n = m)
                                                              | (VBool b1, VBool b2) -> VBool (b1 = b2)
                                                              | (VObj o1, VObj o2) -> VBool (o1 == o2) 
                                                              | _ -> failwith "Les types des expressions ne sont pas compatibles pour la comparaison ==."
                              )
        | Binop (Neq,e1,e2) -> ( match (eval e1,eval e2) with
          | (VInt n,VInt m) -> let b = (n<>m) in VBool b
          | (VBool b1,VBool b2) -> let b = (b1<>b2) in VBool b
          | (VObj o1,VObj o2) -> let b = (o1<>o2) in VBool b
          | _ -> assert false
          )

        | Binop(And, e1, e2) -> VBool(evalb e1 && evalb e2 )
        | Binop(Or, e1, e2) -> VBool(evalb e1 || evalb e2)
        
        | Binop (Eqs,e1,e2) -> ( let extract_values hash_tbl =
                let add_value_to_list key value acc = value :: acc in
                Hashtbl.fold add_value_to_list hash_tbl []
              in
              let rec eqs v1 v2 =
                match (v1,v2) with
                | (VInt n,VInt m) -> let b = (n=m) in b
                | (VBool b1,VBool b2) -> let b = (b1=b2) in b
                | (VObj o1,VObj o2) -> let b1 = (o1.cls=o2.cls) in
                                      let l1 = extract_values o1.fields in
                                      let l2 = extract_values o2.fields in
                                      let b2 = List.for_all2 (fun x y -> eqs x y) l1 l2 in
                                      b1 && b2
                | _ -> assert false
              in
              VBool (eqs (eval e1) (eval e2))
            )
        | Binop (Neqs,e1,e2) -> ( let extract_values hash_tbl =
                  let add_value_to_list key value acc = value :: acc in
                  Hashtbl.fold add_value_to_list hash_tbl []
                in

                let rec neqs v1 v2 =
                match (v1,v2) with
                | (VInt n,VInt m) -> let b = (n<>m) in b
                | (VBool b1,VBool b2) -> let b = (b1<>b2) in b
                | (VObj o1,VObj o2) -> let b1 = (o1.cls<>o2.cls) in
                                      let l1 = extract_values o1.fields in
                                      let l2 = extract_values o2.fields in
                                      let b2 = List.exists2 (fun x y -> neqs x y) l1 l2 in
                                      b1 || b2
                | _ -> assert false
                in
                VBool (neqs (eval e1) (eval e2))
        )
        | This -> ( match Hashtbl.find_opt lenv "this" with
                            | Some v -> v
                            | None -> failwith "Impossible de trouver le parametre implicite 'this'"
        )
        
        | Get m -> begin
          match m with
          | Var s -> (
              match (Hashtbl.find_opt lenv s, Hashtbl.find_opt env s) with
                  | (Some lenv_value, _) -> lenv_value
                  | (_, Some env_value) -> env_value
                  | (None, None) -> (
                                      match List.find_opt (fun c -> c.class_name = s) p.classes with
                                      | Some _ -> VObj { cls = s; fields = Hashtbl.create 0 } 
                                      | None -> failwith (Printf.sprintf "La variable ou classe %s n'est pas declaree" s)
                                    )
                  
          )
          | Field (e,s) -> begin
                            match eval e with
                            | VObj o ->
                                        if Hashtbl.mem o.fields s then
                                          Hashtbl.find o.fields s
                                        else
                                          let find_static_attribute class_name attribut_name =
                                            match Hashtbl.find_opt static_env (Printf.sprintf "%s.%s" class_name attribut_name) with
                                            | Some (Some e)->eval e
                                            | Some (None)->failwith (Printf.sprintf "l'attribut statique %s de la classe %s n'a pas ete initialise" attribut_name class_name)
                                            | None -> failwith (Printf.sprintf "l'attribut statique %s n'existe pas dans la classe %s" attribut_name class_name)
                                          in
                                          find_static_attribute o.cls s  
                            | _ -> failwith "type invalide."
                          end
                  end
                
        | New id -> ( match List.find_opt (fun c -> c.class_name = id) p.classes with
                  | Some class_ ->
                      let fields = Hashtbl.create 0 in
                      let () = List.iter (fun (x, _,_, is_static,_,_,val_option) -> 
                                                                                    if is_static then Hashtbl.add env (Printf.sprintf "%s.%s" id x) Null
                                                                                    else 
                                                                                          let valeur = match val_option with 
                                                                                                                          | Some e -> eval e
                                                                                                                          | None -> Null
                                                                                          in
                                        Hashtbl.add fields x valeur) class_.attributes in
                      VObj {cls = class_.class_name ; fields}
                  | None -> let error_msg = Printf.sprintf "La classe %s est inexistane" id in
                          failwith error_msg
                  )
        | NewCstr (id,l) -> ( match List.find_opt (fun c -> c.class_name = id) p.classes with
                            | Some class_ ->
                                    let o = {cls = class_.class_name ; fields = Hashtbl.create 0} in
                                    let evl = List.map (fun e -> eval e) l in
                                    eval_call (find_method o.cls "constructor") (VObj o) evl
                            | None -> let error_msg = Printf.sprintf "La classe %s est inexistante" id in
                                      failwith error_msg
                            )
        | MethCall (e,id,l) -> ( match eval e with
                            | VObj o ->
                                let m = find_method o.cls id in
                                let evl = List.map (fun e -> eval e) l in
                                eval_call m (VObj o) evl
                            | _ -> assert false
                              )
        | ArrayCall (s,l) -> (match s,l with   
                              | "get",[t;x] -> eval ( Array.get (Array.of_list !(evalt t)) (evali x) )
                              | "set",[t;i;x] -> Fonctions.list_set (evalt t) (evali i) x ; Null
                              | _ -> assert false )
        | InstanceOf(e, t) -> (
                                match eval e with
                                                | VObj obj -> VBool (obj.cls = typ_to_string t)
                                                | _ -> VBool false
                            )
        | Super (id, args) ->(
                              let valeur =
                                match Hashtbl.find_opt lenv "this" with
                                | Some v -> v
                                | None -> failwith "paramètre this introuvable"
                              in
                              begin 
                              match valeur with
                              | VObj o ->
                                  let child_class = find_class p o.cls in
                                  let parent_name = match child_class.parent with
                                                                                  | Some name -> name
                                                                                  | None -> failwith (Printf.sprintf "La classe %s n'a pas de classe mère donc  on ne peut pas appliquer super." child_class.class_name)
                                  in
                                  let meth = List.find (fun md -> md.method_name = id) (find_class p parent_name).methods in
                                  let evl = List.map (fun e -> eval e) args in
                                  eval_call meth valeur evl
                              | _ -> failwith " this n'est pas un objet !"
                              end
                              )            
        | _ -> failwith "case not implemented in eval"

      in

      let rec exec (i: instr): unit = match i with
        | Print e -> Printf.printf "%d\n" (evali e)
        | Set (m,e) -> let v = eval e in
                      begin
                      match m with
                      | Var s  -> Hashtbl.replace lenv s v
                      | Field (e,s) -> 
                                        begin
                                          match eval e with
                                          | VObj o ->
                                                      if Hashtbl.mem o.fields s then
                                                        Hashtbl.replace o.fields s v
                                                      else
                                                          let e= match v with
                                                                              | VInt n -> Int n
                                                                              | VBool b -> Bool b
                                                                              | VObj o -> New o.cls 
                                                                              | VArray t -> Array (!t) 
                                                                              | Null -> failwith "Null ne peut pas être converti en expression"
                                                          in
                                                          Hashtbl.replace static_env (Printf.sprintf "%s.%s" o.cls s) (Some e)
                                          | _ -> failwith "type invalide"
                                        end
                      end
        |If(e,l_if,l_else) -> if (evalb e) then (exec_seq l_if)
                              else (exec_seq l_else)
        |While(e,l) -> if (evalb e) then begin exec_seq l ; exec (While(e,l)) end
        |Return(e) -> Hashtbl.add lenv "return" (eval e)  

        | Expr e -> let _ = eval e in ()
      and exec_seq s = 
        List.iter exec s
      in

      exec_seq s
    in
    List.iter (fun (x, e) -> exec_seq ([Set(Var(x),e)]) env) p.globals_init;
    exec_seq p.main (Hashtbl.create 1)
