#!/bin/bash

# Couleurs pour les messages
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

# Fichier contenant les noms des tests
TEST_FILE_LIST="test_files.txt"
EXECUTABLE="./kawai.exe"

# Vérifier si le fichier de liste existe
if [ ! -f "$TEST_FILE_LIST" ]; then
  echo -e "${RED}Fichier $TEST_FILE_LIST introuvable. Crée-le avec les noms des tests à exécuter.${NC}"
  exit 1
fi

# Variable pour suivre le nombre d'erreurs inattendues
UNEXPECTED_ERROR_COUNT=0

# Exécuter chaque test
while IFS= read -r test_file; do
  if [ -n "$test_file" ]; then
    # Vérifier si le test est marqué avec '%'
    EXPECTS_ERROR=false
    if [[ "$test_file" == %* ]]; then
      EXPECTS_ERROR=true
      test_file="${test_file:1}" # Retirer le symbole '%' du nom du fichier
    fi

    echo -e "${YELLOW}Exécution du test : $test_file${NC}"
    dune exec "$EXECUTABLE" -- "$test_file"
    EXIT_CODE=$?

    if [ $EXIT_CODE -ne 0 ]; then
      if $EXPECTS_ERROR; then
        echo -e "${GREEN}Il est normal que ce fichier lève une exception.${NC}"
      else
        echo -e "${RED}Erreur inattendue lors de l'exécution de $test_file.${NC}"
        ((UNEXPECTED_ERROR_COUNT++))
      fi
    elif $EXPECTS_ERROR; then
      echo -e "${RED}ATTENTION : Aucun erreur levée pour un fichier qui en attendait une ($test_file).${NC}"
      ((UNEXPECTED_ERROR_COUNT++))
    fi
  fi
done < "$TEST_FILE_LIST"

echo -e "${YELLOW}Tous les tests ont été exécutés.${NC}"
if [ $UNEXPECTED_ERROR_COUNT -ne 0 ]; then
  echo -e "${RED}Nombre total d'erreurs inattendues ou incohérentes : $UNEXPECTED_ERROR_COUNT${NC}"
else
  echo -e "${GREEN}Aucune erreur inattendue détectée.${NC}"
fi
