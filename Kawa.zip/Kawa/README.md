Projet COMPILATION : ALIF Yassine, KEBDI Lounès, LONGUEPEE Lubin (2025)

Ce fichier readme correspond au rapport de projet

Remarque :
Vous pouvez exécuter tous les tests d'un coup en compilant (dune build) puis en exécutant la commande "./run_tests.sh". A noter que nous avons réalisés des tests supplémentaires pour toutes les extensions que nous avons traitées de façon à couvrir une majorité des cas d'utilisation possibles. Les noms des fichiers de tests ".kwa" correspondent un maximum possible aux noms des extensions traitées.

Nous avons réalisé l'ensemble du projet de façon à ce que tout fonctionne et nous avons rajouté ces extensions:
	-Champs immuables
	-Visibilités
	-Déclarations en série
	-Déclaration avec valeur initiale
	-Champs statiques
	-Test de type
	-Super
	-Tableaux
	-Égalité structurelle
	-Déclarations simplifiées

Les difficultés que nous avons rencontrées ont été 
	-Rendre le code fonctionnel si on combine les extensions "déclaration en série" et "déclaration avec valeur initiale" afin de rendre possible le fait d'écrire "int x,y=1,2"
	-Rendre fonctionnel sémantiquement les "extends" et faire en sorte qu'ils fonctionnent dans tous les cas d'utilisation possibles

Nous avons rencontrés d'autres difficultés mineures mais qui ne nous ont pas pénalisées longuement.