open Kawa

module Env = Map.Make(String)
type tenv = typ Env.t

let fOLD = 50


let list_set (l:'a list ref) (i:int) (x:'a) =
  let rec list_rec_loop (l':'a list) (l'':'a list) (i':int) =
    match l'' with
    | [] -> ()
    | hd::tl -> if i'=0 then l:= (List.rev l')@(x::tl)
               else list_rec_loop (hd::l') tl (i-1)
  in
  list_rec_loop [] !l i