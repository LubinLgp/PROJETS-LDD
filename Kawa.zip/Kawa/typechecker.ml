open Kawa

exception Error of string
let error s = raise (Error s)
let type_error ty_actual ty_expected =
  error (Printf.sprintf "expected %s, got %s"
           (typ_to_string ty_expected) (typ_to_string ty_actual))

module Env = Map.Make(String)
type tenv = typ Env.t

let add_env l tenv =
  List.fold_left (fun env (x, t) -> Env.add x t env) tenv l

let typecheck_prog p =
  let actual_class = ref "main" in
  let actual_method = ref "main" in
  (*let () = Fonctions.print_classes p  in*)

  (*Trouve la classe de nom [cname] parmi les classes de [p] et lève une exception sinon*)
  let find_class cname =
    match List.find_opt (fun cdef -> cdef.class_name = cname) p.classes with
    | Some v -> v
    | None -> failwith (Printf.sprintf"La classe %s est inexsistante" cname)
  in

    (*Trouve la méthode de nom [name] de la classe [cl] et lève une exception sinon*)
  let find_meth name cl =
    match List.find_opt (fun cmet -> cmet.method_name = name) cl.methods with
    | Some v -> v
    | None -> failwith (Printf.sprintf "La methode %s est inexistante pour la classe %s" name cl.class_name)
  in
  (*Trouve l'argument de nom [s] de la classe [c] et lève une exception sinon*)
  let rec find_arg s cl =
    match List.find_opt (fun (aname, _, _, _,_,c,_) -> aname = s) cl.attributes with 
    | Some v -> v 
    | None -> match cl.parent with
                                  | Some parent_name ->
                                                        let parent_class = find_class parent_name in
                                                        find_arg s parent_class
                                  | None -> failwith (Printf.sprintf "Attribut %s inexistant pour la classe %s" s cl.class_name)   
    in
  (*Regarde si la classe c1 est une classe fille de la classe c2*)
  let check_subclass c1 c2 =
    let rec aux cl =
      if cl.class_name <> c2.class_name then 
        match cl.parent with
        | None -> let errorMessage = "La classe " ^ cl.class_name ^ " n'est pas une sous-classe de " ^ c2.class_name in
        failwith errorMessage
        | Some parent_class -> aux (find_class parent_class)
      in
      aux c1
  in

   (*Regarde si le type c1 est un sous-type du type c2*)
   let check_subtype t1 t2 =
    if t1 <> t2 then
      match t1, t2 with
      | TClass(s1), TClass(s2) -> let c1 = find_class s1 in
                                  let c2 = find_class s2 in
                                  check_subclass c1 c2
      | _ -> failwith("Les 2 types sont differents")
  in

  let tenv = add_env p.globals Env.empty in

  let rec check e typ tenv =
    let typ_e = type_expr e tenv in
    if typ_e <> typ then type_error typ_e typ

  and type_expr e tenv = match e with
    | Int _  -> TInt
    | Bool _ -> TBool
    | Binop(Add,e1,e2) ->
      let () = check e1 TInt tenv in
      let () = check e2 TInt tenv in
      TInt
    | Binop(Sub,e1,e2) ->
      let () = check e1 TInt tenv in
      let () = check e2 TInt tenv in
      TInt
    | Binop(Mul,e1,e2) ->
      let () = check e1 TInt tenv in
      let () = check e2 TInt tenv in
      TInt
    | Binop(Div,e1,e2) ->
      let () = check e1 TInt tenv in
      let () = check e2 TInt tenv in
      TInt
    | Binop(Rem,e1,e2) ->
      let () = check e1 TInt tenv in
      let () = check e2 TInt tenv in
      TInt
    | Binop(Lt,e1,e2) ->
      let () = check e1 TInt tenv in
      let () = check e2 TInt tenv in
      TBool
    | Binop(Le,e1,e2) ->
      let () = check e1 TInt tenv in
      let () = check e2 TInt tenv in
      TBool
    | Binop(Gt,e1,e2) ->
        let () = check e1 TInt tenv in
        let () = check e2 TInt tenv in
        TBool
    | Binop(Ge,e1,e2) ->
        let () = check e1 TInt tenv in
        let () = check e2 TInt tenv in
        TBool

    | Binop(Eq,e1,e2) ->
          let t1 = type_expr e1 tenv in
          let t2 = type_expr e2 tenv in
          if t1 = t2 then
            TBool
          else
            failwith("Les deux expressions ne sont pas du meme type")
    | Binop(Neq,e1,e2) ->
          let t1 = type_expr e1 tenv in
          let t2 = type_expr e2 tenv in
          if t1 = t2 then
            TBool
          else
            failwith("Les deux expressions ne sont pas du meme type")
    | Binop(Eqs,e1,e2) ->
      let t1 = type_expr e1 tenv in
      let t2 = type_expr e2 tenv in
      if t1 = t2 then
        TBool
      else
        failwith("Les deux expressions ne sont pas du meme type")
    | Binop(Neqs,e1,e2) ->
        let t1 = type_expr e1 tenv in
        let t2 = type_expr e2 tenv in
        if t1 = t2 then
          TBool
        else
          failwith("Les deux expressions ne sont pas du meme type")
    | Unop(Not,e) ->
      let () = check e TBool tenv in
      TBool
    | Unop(Opp,e) ->
        let () = check e TInt tenv in
        TInt
    | This -> ( match Env.find_opt "this" tenv with
      | Some v -> v
      | None -> failwith "Impossible de trouver le parametre this"
      )
    | Array t -> ( match t with 
      | [] -> failwith ("Tableau vide")
      | _ -> let t_ref = type_expr (List.hd t) tenv in 
             List.iter ( fun x -> check x t_ref tenv ) t ;
             TArray(t_ref)
    )
    | InstanceOf(e, t) -> (
                        let type_e = type_expr e tenv in
                        match type_e with
                                      | TClass _ -> TBool
                                      | _ -> failwith "InstanceOf ne peut qu'etre utilise avec des classes."
                        )
  
    | Super(id, args) -> (
                          let current_class_name = !actual_class in
                          let current_class = find_class current_class_name in
                          match current_class.parent with
                          | None -> failwith (Printf.sprintf "La classe %s n'a pas de classe mere" current_class_name)
                          | Some parent_class_name ->
                              let parent_class = find_class parent_class_name in
                              let method_def = find_meth id parent_class in
                              if List.exists (fun m -> m.method_name = id) parent_class.methods then
                                let expected_types = List.map (fun (_,t)->t) method_def.params in
                                let actual_types = List.map (fun arg -> type_expr arg tenv) args in
                                List.iter2 (fun expected actual -> check_subtype actual expected) expected_types actual_types;
                                method_def.return
                              else
                                failwith (Printf.sprintf "La methode %s n'existe pas dans la classe mere %s" id parent_class_name)
                        )

    | Get(e) -> type_mem_access e tenv
    | New(id) ->
      let _ = find_class id in
      TClass(id)

    | NewCstr(id, l) ->
      let c = find_class id in
      let constr = find_meth "constructor" c in
      let t_ret = if (constr.return = TVoid) then true else false in
      let typ_params = List.map (fun (x, y) -> y) constr.params in
      let typ_l = List.map (fun x -> type_expr x tenv) l in
      let () = List.iter2 (fun x y -> check_subtype x y) typ_l typ_params in
      if t_ret then
        TClass(id)
      else 
        failwith("Les types attendus du constructeur ne coincident pas avec les types donnees en argument ou le type de retour de la fonction n'est pas TVoid")

    | MethCall(e,s,l) -> 
      let t0 = type_expr e tenv in
      ( match t0 with
      | TClass cname ->
        let c = find_class cname in
        let method_ = find_meth s c in
        let t = method_.return in
        let typ_params = List.map (fun (x, y) -> y) method_.params in
        let typ_l = List.map (fun x -> type_expr x tenv) l in
        begin
        (match ((find_meth s c).visibility,(find_meth s c).class_decl)  with
        | (Public,_) -> ()
        | (Protected, cm) -> (match !actual_class with
                      | "main" -> let error_message = Printf.sprintf "La methode %s de la classe %s est protected. Le main n'y a pas acces" s cm in
                                  failwith error_message 
                      | _ -> (try
                                check_subclass c (find_class cm);
                              with
                                | _ -> let error_message = Printf.sprintf "La methode %s de la classe %s est private. La classe %s n'y a pas acces" s cm cname in
                                        failwith error_message ))
        | (Private, cm) -> (match !actual_class with
                    | "main" -> let error_message = Printf.sprintf "La methode %s de la classe %s est private. Le main n'y a pas acces" s cname in
                                failwith error_message 
                    | _ -> if cm <> cname then let error_message = Printf.sprintf "La methode %s de la classe %s est private. La classe %s n'y a pas acces" s cm cname in
                            failwith error_message));
        (try
              let () = List.iter2 (fun x y -> check_subtype x y) typ_l typ_params in
              t
        with
        | _ -> failwith("Les types attendus de la methode ne coincident pas avec les types donnees en argument")
        )
        end
      | _ -> failwith("Le type sur lequel vous realisez l'appel de la methode n'est pas un TClass")
      )
  
    | ArrayCall(s,l) ->(
        match s,l with 
        | "get",[e1;e2] -> check e2 TInt tenv; 
                           let t = type_expr e1 tenv in
                           ( match t with
                            | TArray typ -> typ
                            | _ -> let error_message = Printf.sprintf "Impossible d'appeler la fonction %s avec ces arguments" s in
                                   failwith error_message
                          )
        | "set",[e1;e2;e3] -> check e2 TInt tenv;
                              let t1 = type_expr e1 tenv in 
                              let t3 = type_expr e3 tenv in 
                             ( match t1 with
                                | TArray typ -> 
                                  if t3 <> typ then 
                                    let error_message = Printf.sprintf "Le tableau est un %s mais contient un %s" (typ_to_string t1) (typ_to_string t3) in
                                    failwith (error_message)
                                  else TVoid
                                | _ -> let error_message = (Printf.sprintf "Impossible d'appeler la fonction %s avec ces arguments" s )in
                                      failwith error_message
                                )                     
        | _ -> let error_message = (Printf.sprintf "La fonction %s n'existe pas sur les Arrays" s) in
            failwith error_message )
    | _ -> failwith "case not implemented in type_expr"

  
  and type_mem_access m tenv = match m with
    | Var s ->  
                ( try Env.find s tenv with 
                | Not_found -> (try find_class s; TClass s with 
                                | Not_found -> failwith (Printf.sprintf "La variable ou classe %s est inexistante" s))                 
    )
    | Field (e,s) ->
       let t = type_expr e tenv in
       match t with
       
       | TClass n -> let c = find_class n in
                     ( match (find_arg s c) with
                     | (_,t,v,is_static,_,cm,_) ->
                                                 begin
                                                      let is_this e =
                                                        match e with
                                                        | This -> true
                                                        | _ -> false
                                                      in
                                                      if is_static && (is_this e) then failwith (Printf.sprintf "L'attribut %s de la classe %s est static et doit être accede via le nom de la classe." s n)
                                                      else 
                                                      ( match v with
                                                                      | Public -> t
                                                                      | Protected -> (match !actual_class with
                                                                                    | "main" -> let error_message = Printf.sprintf "L'attribut %s de la classe %s est protected. Le main n'y a pas acces" s cm in
                                                                                                failwith error_message 
                                                                                    | _ -> (try
                                                                                              begin (check_subclass c (find_class cm)) ; t end
                                                                                            with
                                                                                              | _ -> let error_message = Printf.sprintf "L'attribut %s de la classe %s est private. La classe %s n'y a pas acces" s cm n in
                                                                                                      failwith error_message ))
                                                                        | Private -> (match !actual_class with
                                                                                    | "main" -> let error_message = Printf.sprintf "L'attribut %s de la classe %s est private. Le main n'y a pas acces" s n in
                                                                                                failwith error_message 
                                                                                    | _ -> if cm = n then t
                                                                                            else let error_message = Printf.sprintf "L'attribut %s de la classe %s est private. La classe %s n'y a pas acces" s cm !actual_class in
                                                                                                failwith error_message)                                                              
                                                      )
                                                end
           )
       | _ -> failwith "[e] n'est pas de type TClass"   
  in



  let rec check_instr i ret tenv = match i with
    | Print e -> check e TInt tenv
    | Set (m,e) -> ( match m with 
                    | Field (e,s) ->  let t = type_expr e tenv in 
                                  ( match t with
                                  | TClass n -> let c = find_class n in
                                                let (s, typ, _, is_static, is_final,_,_) = find_arg s c in
                                                let is_this e =
                                                  match e with
                                                  | This -> true
                                                  | _ -> false
                                                in
                                                if is_static && (is_this e) then failwith (Printf.sprintf "L'attribut %s de la classe %s est static et doit être accede via le nom de la classe." s n)
                                                else 
                                                ( match is_final with
                                                                      | false -> ()
                                                                      | true -> if !actual_method <> "constructor" || !actual_class <> n then
                                                                                        let error_message = ( Printf.sprintf "L'attribut %s ne peut pas etre modifie dans %s.%s"
                                                                                                  s !actual_class !actual_method) in
                                                                                        failwith(error_message)
                                                                                else if is_static then 
                                                                                                        let error_message = ( Printf.sprintf "L'attribut %s a deja ete initialisee il ne peut plus etre modifie" s ) in
                                                                                                        failwith(error_message)                      
                                                ) 
                                  | _ -> failwith "[e] n'est pas de type TClass" 
                                  ) 
                    | _ -> () 
                    );
                   let tG = type_mem_access m tenv in
                   let tD = type_expr e tenv in
                   check_subtype tD tG
    
    | Expr e -> check e TVoid tenv 
    | If (e,l_if,l_else) ->
      check e TBool tenv;
      check_seq l_if ret tenv;
      check_seq l_else ret tenv
    | While (e,l) ->
      check e TBool tenv;
      check_seq l ret tenv
    | Return (e) -> check e ret tenv
  and check_seq s ret tenv =
    List.iter (fun i -> check_instr i ret tenv) s
  in

  let check_class c =
    let () = actual_class := c.class_name in

    actual_class := c.class_name;

    let check_mdef m tenv =
        let () = actual_method := m.method_name in
        let new_tenv = add_env (m.params@m.locals) tenv in
        actual_method := m.method_name;
        check_seq m.code m.return new_tenv;
    in

    let tenv = add_env p.globals Env.empty in
    let new_tenv = Env.add "this" (TClass c.class_name) tenv in
    List.iter (fun m -> check_mdef m new_tenv) c.methods
 in

 check_seq p.main TVoid tenv;
 List.iter check_class p.classes